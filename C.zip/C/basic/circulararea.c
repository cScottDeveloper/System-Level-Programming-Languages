// function definition of circularArea()
double circularArea(double r)
{
	const double pi = 3.1415926536;
	return pi * r * r;
}

