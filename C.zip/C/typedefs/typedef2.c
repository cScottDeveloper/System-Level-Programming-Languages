#include <stdio.h>

typedef int Int32;

int main() {

	Int32 a;

	printf("Size of Int32 type: %lu\n", sizeof(Int32));
	
	return 0;

}
